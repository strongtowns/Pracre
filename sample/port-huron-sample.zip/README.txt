City of Port Huron, Michigan, 2024 parcels (Active_Parcels) and taxable values.
Parcels: parcel number, property address, ZIP code and zoning; owner names and mailing addresses are left out.
Values: ParcelMaster.parcelnumber and Parcels.current_taxable (Michigan taxable value).
