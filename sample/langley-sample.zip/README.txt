Township of Langley open data, 2024 (the whole township).
Parcels: https://data-tol.opendata.arcgis.com/datasets/cc82def6b6b54586aa7a1e452fcc1f02_0/
Assessments: https://data-tol.opendata.arcgis.com/datasets/6f63c681511e4856836a7c9f988a0a6f_0/
Contains information licensed under the Open Government Licence - Township of Langley.
